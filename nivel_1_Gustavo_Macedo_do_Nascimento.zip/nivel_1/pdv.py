
#Loop de compras:

   # O programa deve permitir várias compras seguidas.

   # O loop só termina quando o usuário digitar 0 no valor da compra. 
valores_brutos = []
valores_descontados = []


while True:
    print("Digite 0 no valor da compra para encerrar o programa.")

    valor_de_compra = float(input("Digite o valor de compra: "))
    if valor_de_compra == 0:
            print("Programa encerrado.")
            break
    if valor_de_compra < 0:
            print("Valor de compra inválido. Digite um valor válido.")
            continue
    idade =  int(input("Digite sua idade: "))
    while idade < 0:
        print("Idade inválida. Digite uma idade válida.")
        idade =  int(input("Digite sua idade: "))
        continue
    

    valores_brutos.append(valor_de_compra)
    

           

    #Regra 1 — Desconto por idade:
    #Se a idade for maior ou igual a 65 anos, aplicar 20% de desconto.


    

    if idade >= 65:
        desconto = valor_de_compra * 0.20


        valor_de_compra_com_desconto =  valor_de_compra - desconto
       
       
        valores_descontados.append(desconto)
        valor_de_compra = valor_de_compra_com_desconto


        if valor_de_compra_com_desconto > 100.00:
            desconto_extra = valor_de_compra_com_desconto * (10 /100)
            
            valor_de_compra = valor_de_compra_com_desconto - desconto_extra
           
            valores_descontados.append(desconto_extra)
            

    elif valor_de_compra > 100.00:
        desconto_extra = valor_de_compra * (10 /100)
        valor_de_compra = valor_de_compra - desconto_extra
       
        valores_descontados.append(desconto_extra)




    
    print(f"Value a pagar: R$ {valor_de_compra:.2f}" )
total_bruto = sum(valores_brutos)
total_descontado = sum(valores_descontados)

quantidade_compras = len(valores_brutos)
total_final = total_bruto - total_descontado

print("\nResumo das compras:")
print(f"Quantidade de compras: {quantidade_compras}" )
print(f"Total bruto: R$ {total_bruto:.2f}" )
print(f"Total descontado: R$ {total_descontado:.2f}" )
print(f"Total final: R$ {total_final:.2f}" )



