Desafio Nível 1 — PDV com Descontos (Python)
Contexto

A base de qualquer sistema é saber tomar decisões simples baseadas em regras de negócio. Neste desafio, você vai construir a lógica de um PDV (Ponto de Venda) que aplica descontos progressivos — o tipo de cálculo que existe em qualquer loja, farmácia ou supermercado.


O código recebe o valor e a idade, verifica se a idade é maior ou igual a 65 para aplicar 20%, depois verifica se o valor já descontado passa de 100 para aplicar mais 10%, guarda cada compra numa lista e, ao final, soma tudo e mostra o resumo


Como rodar: o comando para executar o programa (py pdv.py).


exemplo: 
![
    
](<Screenshot 2026-10-24 at 12-08-21 Challenge details Dashboard - Plataforma Mais Robotic.png>)


